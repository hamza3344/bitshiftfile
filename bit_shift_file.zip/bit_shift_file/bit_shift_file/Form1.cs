﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace bit_shift_file
{
    public partial class Form1 : Form
    {
        string encrypt;
        string decrypto;
        int shft = 3;//change according to need
        int divider = 3;//change according to need
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = File.ReadAllText("C:\\security\\file.txt");
            encrypt = text.Select(c => ((int)c) << shft)
                .Aggregate("", (current, val) => current + (char)(val * divider));
            encrypt = Convert.ToBase64String(Encoding.UTF8.GetBytes(encrypt));
            File.WriteAllText("C:\\security\\encrypt.txt", encrypt);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texxt = File.ReadAllText("C:\\security\\encrypt.txt");
            decrypto=Encoding.UTF8.GetString(Convert.FromBase64String(texxt))
                .Select(c => ((int)c) >> shft)
                .Aggregate("", (current, val) => current + (char)(val / divider));
            File.WriteAllText("C:\\security\\decrypto.txt", decrypto);
        }
    }
}
